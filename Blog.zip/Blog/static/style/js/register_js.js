$(function () {
    $('#img').change(function () {
        // 获取文件对象
        var file = $('#img')[0].files[0];
        // 获得文件对象的路径（文件阅读器）
        var reader = new FileReader();
        reader.readAsDataURL(file);//阅读文件的路径，并把结果保存在reader.result
        //更改文件路径(与reader.readAsDateURL是异步操作，需要用onload加载完再执行)
        reader.onload = function(){
            $('#image').attr('src',reader.result)}
    })

    $('#btn').click(function () {
        var formdata = new FormData;
        formdata.append('user',$('#id_user').val());  //从form传来组件，默认id=id_组件名
        formdata.append('pwd',$('#id_pwd').val());
        formdata.append('re_pwd',$('#id_re_pwd').val());
        formdata.append('email',$('#id_email').val());
        formdata.append('img',$('#img')[0].files[0]);
        formdata.append('csrfmiddlewaretoken',$('[name =csrfmiddlewaretoken]').val());

        $.ajax({
            url:'',
            type:'POST',
            contentType:false,
            processData:false,
            data:formdata,
            success:function (data) {

                if(data.user){
                    location.href= '/login/'
                }
                else{
                    console.log(data['msg']);
                    //清空错误信息
                    $('.err_info').text('');
                    $('.form-group').removeClass('has-error');
                    //循环打印msg中的错误信息
                    $.each(data['msg'],function (msg_k,msg_v) {
                        //判断是不是全局钩子
                        if(msg_k=='__all__'){
                            $('#id_re_pwd').next().text(msg_v)
                            $('#id_pwd,#id_re_pwd').parent().addClass('has-error')
                        }
                        $('#id_'+msg_k).next().text(msg_v);
                        $('#id_'+msg_k).parent().addClass('has-error')  // 添加错误边框样式
                    })
                }
            }
        })
    })
})