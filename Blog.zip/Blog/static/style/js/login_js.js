$(function () {
    $('#btn').click(function () {
        $.ajax({
            url:'/login/',
            type:'POST',
            data:{
                user:$('#user').val(),
                pwd:$('#pwd').val(),
                captcha:$('#captcha').val(),
                //ajax自己组件{% csrf_token %}
                csrfmiddlewaretoken:$('[name=csrfmiddlewaretoken]').val(),
            },
            success:function (data) {
                console.log(data);
                if(data['user']){
                    location.href = '/index/'
                }
                else{
                    $('.error').text(data['msg']).css({'color':'red','text-align':'right'})
                }
            }
        })
    });


    //验证码刷新
    $('#img').click(function () {
        $(this)[0].src += '?'
    })
});