import json
import os
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import auth
from django.http import JsonResponse
from django import forms
from django.forms import widgets
from django.core.exceptions import ValidationError
from django.db.models import Count
from django.db.models import F
from django.db import transaction
from django.contrib.auth.decorators import login_required
from app01.pack_models.get_captcha import get_captcha
from app01.models import *
from app01.models import UserInfo
from Blog import settings


# Create your views here.

def login(request):
    user_info = {'user': None, 'msg': None}
    if request.method == 'POST':
        user = request.POST.get('user')
        pwd = request.POST.get('pwd')
        captcha = request.POST.get('captcha')
        if captcha.upper() == request.session['code_str'].upper():
            user = auth.authenticate(username=user, password=pwd)
            if user:
                auth.login(request, user)
                user_info['user'] = user.username
            else:
                user_info['msg'] = '账号、密码错误'
        else:
            user_info['msg'] = '验证码错误'

        return JsonResponse(user_info)  # 无需反序列化
    return render(request, 'login.html')


def logout(request):
    auth.logout(request)
    return redirect('/login/')


"""pip install Pillow"""
# 获得验证码
def get_img(request):
    data = get_captcha(request)
    return HttpResponse(data)


def index(request):
    art_list = Article.objects.all()
    return render(request, 'index.html', locals())


class UserForm(forms.Form):
    user = forms.CharField(max_length=32, label='用户名',  # 设置lable标签
                           error_messages={'required': '该字段不能为空'},  # 当用户未输入时报的错
                           widget=widgets.TextInput(attrs={'class': 'form-control'}))  # 设置input的type 添加类标签
    pwd = forms.CharField(max_length=32, label='密码',
                          widget=widgets.PasswordInput(attrs={'class': 'form-control'}))
    re_pwd = forms.CharField(max_length=32, label='确认密码',
                             widget=widgets.PasswordInput(attrs={'class': 'form-control'}))
    email = forms.EmailField(max_length=32, label='电子邮箱',
                             error_messages={'required': '格式错误'},
                             widget=widgets.EmailInput(attrs={'class': 'form-control'}))

    # 建立局部钩子
    def clean_user(self):
        user = self.cleaned_data.get('user')  # 已经过校验
        user_obj = UserInfo.objects.filter(username=user).first()
        if user_obj:
            # 已被注册
            raise ValidationError('该用户已注册')
        else:
            return user

    # 建立全局钩子
    def clean(self):
        pwd = self.cleaned_data.get('pwd')
        re_pwd = self.cleaned_data.get('re_pwd')

        if pwd == re_pwd:
            return self.cleaned_data
        else:
            raise ValidationError('密码不一致')


def register(request):
    form = UserForm()  # 生成form组件
    send_info = {'user': None, 'msg': None}
    if request.method == 'POST':
        form_obj = UserForm(request.POST)
        if form_obj.is_valid():  # form表单进行格式校验
            send_info['user'] = form_obj.cleaned_data.get('user')

            user = request.POST.get('user')
            pwd = request.POST.get('pwd')
            re_pwd = request.POST.get('re_pwd')
            email = request.POST.get('email')
            img = request.FILES.get('img')

            if img:
                # 非明文存储
                UserInfo.objects.create_user(username=user, password=pwd, email=email, avatar=img)
            else:
                UserInfo.objects.create_user(username=user, password=pwd, email=email)

        else:
            print(form_obj.cleaned_data)  # 存放了所有正确信息
            print(form_obj.errors)  # 存放了所有错误信息
            send_info['msg'] = form_obj.errors  # 全局变量信息K为__all__
        return JsonResponse(send_info)
    return render(request, 'register.html', locals())


def get_data(username):
    res = UserInfo.objects.filter(username=username).first()
    # 显示站点内每个分类对应的文章数
    cate_list = Category.objects.filter(blog_id=res.pk).annotate(c=Count('article__category_id')).values('title', 'c')
    # 显示站点内每个分类对应的文章数
    tag_list = Tag.objects.filter(blog_id=res.pk).annotate(c=Count('article2tag__tag_id')).values('title', 'c')
    # 显示每月的博客数
    date_list = Article.objects.filter(user_id=res.pk).extra({'date': "date_format(create_time,'%%Y-%%m')"}).values(
        'date').annotate(c=Count('nid')).values('date', 'c')
    return {'res': res, 'cate_list': cate_list, 'tag_list': tag_list, 'date_list': date_list}


def per_site(request, username, **kwargs):
    data = get_data(username)
    res = data['res']
    if res:
        # http: // 127.0.0.1: 8000 / zzw / cate / python /
        if kwargs:
            style = kwargs['style']
            info = kwargs['info']
            if style == 'cate':
                art_list = Article.objects.filter(user_id=res.pk).filter(category__title=info)
            elif style == 'tag':
                art_list = Article.objects.filter(user_id=res.pk).filter(tag__title=info)
            else:
                # 调整时区 settings USE_TZ = False
                year, month = info.split('-')
                print(year, month)
                art_list = Article.objects.filter(user_id=res.pk).filter(create_time__year=year,
                                                                         create_time__month=month)
        else:
            art_list = Article.objects.filter(user_id=res.pk)  # 显示站点内的所有文章

        return render(request, 'per_site.html', locals())
    else:
        return render(request, 'no_user.html')


def article(request, username, article_id):
    data = get_data(username)
    art_obj = Article.objects.filter(pk=article_id).first()
    comment_list = Comment.objects.filter(article_id=article_id)
    return render(request, 'article.html', locals())


def up_down(request):
    sign = request.POST.get('sign')
    sign = json.loads(sign)  # 前端数据默认以json传来，将‘true’进换成布尔值
    article_id = request.POST.get('article_id')

    send_info = {'state': True}
    obj = ArticleUpDown.objects.filter(article_id=article_id, user_id=request.user.pk).first()
    if not obj:
        ArticleUpDown.objects.create(is_up=sign, article_id=article_id, user_id=request.user.pk)
        if sign == True:
            Article.objects.filter(pk=article_id).update(up_count=F('up_count') + 1)
        else:
            Article.objects.filter(pk=article_id).update(down_count=F('down_count') + 1)
    else:
        send_info['state'] = False  # 用户已对文章进行过操作
        send_info['handled'] = obj.is_up
    print(send_info)

    return JsonResponse(send_info)


def comment(request):
    article_id = request.POST.get('article_id')
    content = request.POST.get('content')
    pid = request.POST.get('parent_id')

    # 事务操作
    with transaction.atomic():
        comm_obj = Comment.objects.create(user_id=request.user.pk, content=content, article_id=article_id,
                                          parent_comment_id=pid)
        Article.objects.filter(pk=article_id).update(comment_count=F('comment_count') + 1)

    send_info = {}
    # create_time：<class 'datetime.datetime'>   json序列化无法对对象进行序列换
    send_info['create_time'] = comm_obj.create_time.strftime("%Y-%m-%d %X")
    send_info['username'] = request.user.username
    send_info['content'] = comm_obj.content
    if pid:
        # 如果有父评论
        parent_obj_name = Comment.objects.filter(pk=pid).values('user__username').first()
        send_info['parent_name'] = parent_obj_name['user__username']
        parent_obj = Comment.objects.filter(pk=pid).first()
        send_info['parent_content'] = parent_obj.content

    return JsonResponse(send_info)


def get_tree_data(request):
    article_id = request.GET.get('article_id')
    send_data = list(Comment.objects.filter(article_id=article_id).values('pk', 'content', 'parent_comment_id'))

    return JsonResponse(send_data, safe=False)


@login_required
def setup(request):
    # 后台设置
    user_art_boj = Article.objects.filter(user_id=request.user.pk)
    data = get_data(request.user.username)
    return render(request, 'setup.html', locals())


from bs4 import BeautifulSoup


@login_required
def add_article(request):
    data = get_data(request.user.username)
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get("content")
        soup = BeautifulSoup(content, 'html.parser')
        print(soup)
        # 非法标签过滤防止XSS攻击
        for tag in soup.find_all():
            if tag.name == 'script':
                tag.decompose()

        # 获取文本进行截断，赋值给desc
        desc = soup.text[0:150]
        print(desc)
        Article.objects.create(title=title, content=str(soup), user_id=request.user.pk, desc=desc)
    return render(request, 'add_article.html', locals())


# 文本编辑器文件传输
def upload(request):
    file = request.FILES.get('upload_img')
    path = os.path.join(settings.MEDIA_ROOT, 'add_upload_img', file.name)
    with open(path, 'wb') as f:
        for line in file:
            f.write(line)
    response = {
        'error': 0,
        'url': '/media/add_upload_img/%s' % file.name
    }
    import json
    return HttpResponse(json.dumps(response))


@login_required
def del_article(request, article_id):
    Article.objects.filter(nid=article_id).delete()
    return redirect('/setup/')
