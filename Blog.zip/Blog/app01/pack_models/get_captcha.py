from PIL import Image, ImageDraw, ImageFont
import random
from io import BytesIO

def get_captcha(request):
    """随机生成颜色"""
    def get_color():
        return random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)

    img = Image.new('RGB', (270, 40), color=get_color())  # 生成背景色

    """在背景色中添加文字"""
    draw = ImageDraw.Draw(img)
    word_font = ImageFont.truetype('static/font/msyhbd.ttf', size=25)

    """生成6位字符的随机验证码"""
    code_str = ''
    for i in range(5):
        random_num = str(random.randint(0, 9))
        random_low = chr(random.randint(95, 122))
        random_upper = chr(random.randint(65, 90))
        random_char = random.choice([random_num, random_low, random_upper])
        draw.text((i * 50 + 30, 5), random_char, get_color(), font=word_font)

        # !!!!保存验证码
        code_str += random_char
        request.session['code_str'] = code_str
    print(code_str)

    """噪点"""
    width = 270
    height = 40
    for i in range(10):
        x1 = random.randint(0, width)
        y1 = random.randint(0, height)
        x2 = random.randint(0, width)
        y2 = random.randint(0, height)
        draw.line((x1, y1, x2, y2), fill=get_color())

    """生成图片存储在内存中"""
    f = BytesIO()
    img.save(f, 'png')
    data = f.getvalue()

    return data