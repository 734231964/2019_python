from django.test import TestCase

# Create your tests here.

from bs4 import BeautifulSoup
s1 = '<h1>哈哈哈哈哈哈哈</h1>'
soup = BeautifulSoup(s1, 'html.parser')
desc = soup.text[0:150]
print(desc)