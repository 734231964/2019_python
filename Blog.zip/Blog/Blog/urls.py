"""Blog URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path
from app01 import views
from django.views.static import serve
from Blog import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/',views.login),
    path('get_img/', views.get_img),
    path('index/',views.index),
    re_path(r'^$',views.index),
    path('register/',views.register),
    path('logout/',views.logout),
    # media 在URL中的默认配置
    re_path(r"media/(?P<path>.*)$", serve, {'document_root': settings.MEDIA_ROOT}),
    # 个人站点url
    re_path(r'^(?P<username>\w+)$',views.per_site),
    re_path(r'^(?P<username>\w+)/(?P<style>tag|cate|date)/(?P<info>.*)/$',views.per_site),
    #文章详情页
    re_path(r'(?P<username>\w+)/article/(?P<article_id>\d+)/$',views.article),
    # 点赞
    path('up_down/', views.up_down),
    # 文章评论
    path('comment/', views.comment),
    #查询评论树数据
    path('get_tree_data/',views.get_tree_data),
    #后台管理
    path('setup/',views.setup),
    #添加纹章
    path('add_article/',views.add_article),
    #文本编辑器添加文件
    path('upload/',views.upload),
    #文件删除
    re_path(r'del_article/(?P<article_id>\d+)/$',views.del_article)
]
